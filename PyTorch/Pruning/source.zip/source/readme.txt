Kod dla CORY, został podzielony na 2 pliki, ponieważ najpierw robiłem zadanie w Jupyterze, ale coś nie dawało rady w momencie przywracania bądźreinicjalizacji wag.
Więc przeniosłem się i dokończyłem na Collabie. Notatniki mogą być troche chaotyczne, jednak wszystko co robiłem jest w nich zawarte.

